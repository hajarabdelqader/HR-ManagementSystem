export interface IDaysOff {
  date: Date;
  name: string;
}
