export interface IMonth {
  payslipStartDate: string;
  payslipEndDate: string;
}
