export interface IUser {
  token: string,
  expiration: string,
  fullName: string,
  role: string
}
