export interface IApplicationUser {
  id: string;
  fullName: string;
  email: string;
  roles: string[];
}
