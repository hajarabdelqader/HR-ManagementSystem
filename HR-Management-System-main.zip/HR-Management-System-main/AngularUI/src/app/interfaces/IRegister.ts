export interface IRegister {
  fullName: string;
  email: string;
  password: string;
  confirmPassword: string;
  roleName: string;
}
