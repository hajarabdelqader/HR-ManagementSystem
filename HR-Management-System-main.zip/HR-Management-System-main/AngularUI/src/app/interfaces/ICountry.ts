export interface ICountry {
  value: string
  group: string
  text: string
}
