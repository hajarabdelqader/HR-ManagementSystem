export const environment = {
  production: false,
  // baseUrl: 'http://localhost:5203/api',
  baseUrl: 'https://localhost:7266/api',
};
