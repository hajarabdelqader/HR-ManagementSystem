﻿namespace WebAPI.Models
{
    public enum AttendenceStatus
    {
        Present,
        Absent
    }
}
