﻿namespace WebAPI.Models
{
    public class SalaryReport
    {
        //public int[] EmpIds { get; set; }
        public DateOnly PayslipStartDate { get; set; }
        public DateOnly PayslipEndDate { get; set; }
    }
}
