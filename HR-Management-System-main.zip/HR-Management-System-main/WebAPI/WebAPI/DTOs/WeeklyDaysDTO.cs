using WebAPI.Models;

namespace WebAPI.DTOs
{
    public class WeeklyDaysDTO
    {

        public List<int> days { get; set; }
    }
}
