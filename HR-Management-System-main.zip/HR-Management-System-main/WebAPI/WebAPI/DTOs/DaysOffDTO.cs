﻿namespace WebAPI.DTOs
{
    public class DaysOffDTO
    {
        public DateOnly Date { get; set; }

        public string Name { get; set; }
    }
}
