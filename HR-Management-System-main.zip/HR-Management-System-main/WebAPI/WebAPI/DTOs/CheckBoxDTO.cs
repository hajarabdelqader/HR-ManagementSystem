﻿namespace WebAPI.DTOs
{
    public class CheckBoxDTO
    {
        public string DisplayValue { get; set; }
        public bool IsSelected { get; set; }
    }
}
