﻿namespace WebAPI.Constants
{
    public enum Roles
    {
        SuperAdmin,
        Admin
    }
}
