﻿namespace WebAPI.Constants
{
    public enum Gender
    {
        Male,
        Female
    }
}
