﻿namespace WebAPI.Constants
{
    public enum Modules
    {
        Employees,
        Settings,
        Attendance,
        Salary
    }
}
