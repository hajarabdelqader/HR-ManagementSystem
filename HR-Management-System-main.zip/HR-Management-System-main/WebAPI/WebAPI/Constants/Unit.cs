﻿namespace WebAPI.Constants
{
    public enum Unit
    {
        Hour,
        Money
    }
}